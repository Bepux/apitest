﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class Option
    {
        [Key]
        public int OptionID {get;set;}
        public string Text { get; set;}
        public bool IsRight { get; set; }
        public int QuestionID { get; set; }

        [ForeignKey("QuestionID")]
        [JsonIgnore]
        public virtual Question Question { get; set; }
        [JsonIgnore]
        public virtual IList<Anwser> Anwsers { get; set; }


    }
}
