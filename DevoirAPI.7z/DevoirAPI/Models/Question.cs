﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class Question
    {
        [Key]
        public int QuestionID { get; set; }
        public string Text { get; set; }
        public int Weight { get; set; }
        public string Type { get; set; }
        public int CategoryID { get; set; }

        [ForeignKey("CategoryID")]
        [JsonIgnore]
        public virtual Category Category { get; set; }
        [JsonIgnore]
        public virtual IList<Option> Options { get; set; }
        [JsonIgnore]
        public virtual IList<QuestionQuiz> QuestionQuizs { get; set; }
            
    }
}
