﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class Anwser
    {
        [Key]
        public int AnwserID { get; set; }
        public int OptionID { get; set; }
        public int QuizID { get; set; }

        [ForeignKey("QuizID")]
        public virtual Quiz Quiz { get; set; }
        [ForeignKey("OptionID")]
        public virtual Option Option { get; set; }

    }
}
