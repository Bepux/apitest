﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class QuestionQuiz
    {
        public int QuestionID { get; set; }
        public int QuizID { get; set; }

        [ForeignKey("QuestionID")]
        public virtual Question Question { get; set; }

        [ForeignKey("QuizID")]
        public virtual Quiz Quiz { get; set; }
    }
}
