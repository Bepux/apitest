﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class Quiz
    {
        [Key]
        public int QuizID { get; set; }
        public virtual IList<Anwser> Anwsers { get; set; }
        public virtual IList<QuestionQuiz> QuestionQuizs { get; set; }
    }
}
