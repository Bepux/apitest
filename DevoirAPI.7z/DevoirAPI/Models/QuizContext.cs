﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class QuizContext : DbContext
    {
        public QuizContext()
        {

        }

        public QuizContext(DbContextOptions<QuizContext> options) : base(options)
        {

        }

        public DbSet<Anwser> Anwsers { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Option> Options { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Quiz> Quizs { get; set; }
        public DbSet<QuestionQuiz> QuestionQuizs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<QuestionQuiz>().HasKey(t => new { t.QuestionID, t.QuizID });

            modelBuilder.Entity<Category>().HasData(
                new Category() { CategoryID = 1, Description = "easy" },
                new Category() { CategoryID = 2, Description = "medium"},
                new Category() { CategoryID = 3, Description = "hard"}
                );
            modelBuilder.Entity<Question>().HasData(
                new Question() { QuestionID = 1, Text = "Java is.......", Weight = 1, Type = "multiplechoice", CategoryID = 1 },
                new Question() { QuestionID = 2, Text = "A Java class", Weight = 1, Type = "checkboxes", CategoryID = 2 },
                new Question() { QuestionID = 3, Text = "What is java inheritance?", Weight = 1, Type = "multiplechoice", CategoryID = 2 },
                new Question() { QuestionID = 4, Text = "Polymorphism is the ability of an object to take on many forms.", Weight = 1, Type = "multiplechoice", CategoryID = 3 },
                new Question() { QuestionID = 5, Text = "‘Local variables are declared in methods, constructors, or blocks", Weight = 1, Type = "multiplechoice", CategoryID = 1 },
                new Question() { QuestionID = 6, Text = "……stores a fixed-size sequential collection of elements of the same type ? ", Weight = 1, Type = "multiplechoice", CategoryID = 2 }
                );
            modelBuilder.Entity<Option>().HasData(
                new Option() { OptionID = 1, Text = "a coffee", IsRight = false, QuestionID = 1},
                new Option() { OptionID = 2, Text = "a high-level programming language", IsRight = true, QuestionID = 1 },
                new Option() { OptionID = 3, Text = "a source code editor", IsRight = false, QuestionID = 1 },
                new Option() { OptionID = 4, Text = "is a template that describes the behavior that the object of its type support", IsRight = true, QuestionID = 2 },
                new Option() { OptionID = 5, Text = "can have any number of methods", IsRight = true, QuestionID = 2 },
                new Option() { OptionID = 6, Text = "the process where one class acquires the properties (methods and fields) of another.", IsRight = true, QuestionID = 3 },
                new Option() { OptionID = 7, Text = "a problem that arises during the execution of a program", IsRight = false, QuestionID = 3 },
                new Option() { OptionID = 8, Text = "it mainly used to traverse collection of elements including arrays.", IsRight = false, QuestionID = 3 },
                new Option() { OptionID = 9, Text = "true", IsRight = true, QuestionID = 4 },
                new Option() { OptionID = 10, Text = "false", IsRight = false, QuestionID = 4 },
                new Option() { OptionID = 11, Text = "true", IsRight = true, QuestionID = 5 },
                new Option() { OptionID = 12, Text = "false", IsRight = false, QuestionID = 5 },
                new Option() { OptionID = 13, Text = "variables", IsRight = false, QuestionID = 6 },
                new Option() { OptionID = 14, Text = "arrays", IsRight = true, QuestionID = 6 },
                new Option() { OptionID = 15, Text = "methods", IsRight = false, QuestionID = 6 }
                );
            modelBuilder.Entity<Quiz>().HasData(
                new Quiz() { QuizID = 1},
                new Quiz() { QuizID = 2}
                );
            modelBuilder.Entity<QuestionQuiz>().HasData(
                new QuestionQuiz() { QuestionID = 1, QuizID = 1 },
                new QuestionQuiz() { QuestionID = 2, QuizID = 1 },
                new QuestionQuiz() { QuestionID = 4, QuizID = 1 },
                new QuestionQuiz() { QuestionID = 6, QuizID = 1 },
                new QuestionQuiz() { QuestionID = 1, QuizID = 2 },
                new QuestionQuiz() { QuestionID = 3, QuizID = 2 },
                new QuestionQuiz() { QuestionID = 4, QuizID = 2 },
                new QuestionQuiz() { QuestionID = 5, QuizID = 2 }
                );
            modelBuilder.Entity<Anwser>().HasData(
                new Anwser() { AnwserID = 1, OptionID = 1, QuizID = 1},
                new Anwser() { AnwserID = 2, OptionID = 4, QuizID = 1 },
                new Anwser() { AnwserID = 3, OptionID = 5, QuizID = 1 },
                new Anwser() { AnwserID = 4, OptionID = 6, QuizID = 1 },
                new Anwser() { AnwserID = 5, OptionID = 9, QuizID = 1 },
                new Anwser() { AnwserID = 6, OptionID = 12, QuizID = 1 },
                new Anwser() { AnwserID = 7, OptionID = 14, QuizID = 1 },
                new Anwser() { AnwserID = 8, OptionID = 1, QuizID = 2 },
                new Anwser() { AnwserID = 9, OptionID = 4, QuizID = 2 },
                new Anwser() { AnwserID = 10, OptionID = 7, QuizID = 2 },
                new Anwser() { AnwserID = 11, OptionID = 9, QuizID = 2 },
                new Anwser() { AnwserID = 13, OptionID = 11, QuizID = 2 },
                new Anwser() { AnwserID = 14, OptionID = 13, QuizID = 2 }
                );
        }

    }
}
