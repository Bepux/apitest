﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DevoirAPI.Models
{
    public class QuizInfo
    {
        [JsonProperty("category")]
        public string category { get; set; }

        [JsonProperty("numberOfQuestions")]
        public int numberOfQuestions { get; set; }

    }
}
