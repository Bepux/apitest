﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DevoirAPI.Migrations
{
    public partial class API1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Description = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryID);
                });

            migrationBuilder.CreateTable(
                name: "Quizs",
                columns: table => new
                {
                    QuizID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Quizs", x => x.QuizID);
                });

            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    QuestionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Text = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    Weight = table.Column<int>(type: "int", nullable: false),
                    Type = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    CategoryID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.QuestionID);
                    table.ForeignKey(
                        name: "FK_Questions_Categories_CategoryID",
                        column: x => x.CategoryID,
                        principalTable: "Categories",
                        principalColumn: "CategoryID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Options",
                columns: table => new
                {
                    OptionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Text = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    IsRight = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    QuestionID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Options", x => x.OptionID);
                    table.ForeignKey(
                        name: "FK_Options_Questions_QuestionID",
                        column: x => x.QuestionID,
                        principalTable: "Questions",
                        principalColumn: "QuestionID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "QuestionQuizs",
                columns: table => new
                {
                    QuestionID = table.Column<int>(type: "int", nullable: false),
                    QuizID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionQuizs", x => new { x.QuestionID, x.QuizID });
                    table.ForeignKey(
                        name: "FK_QuestionQuizs_Questions_QuestionID",
                        column: x => x.QuestionID,
                        principalTable: "Questions",
                        principalColumn: "QuestionID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_QuestionQuizs_Quizs_QuizID",
                        column: x => x.QuizID,
                        principalTable: "Quizs",
                        principalColumn: "QuizID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Anwsers",
                columns: table => new
                {
                    AnwserID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    OptionID = table.Column<int>(type: "int", nullable: false),
                    QuizID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Anwsers", x => x.AnwserID);
                    table.ForeignKey(
                        name: "FK_Anwsers_Options_OptionID",
                        column: x => x.OptionID,
                        principalTable: "Options",
                        principalColumn: "OptionID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Anwsers_Quizs_QuizID",
                        column: x => x.QuizID,
                        principalTable: "Quizs",
                        principalColumn: "QuizID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryID", "Description" },
                values: new object[,]
                {
                    { 1, "easy" },
                    { 2, "medium" },
                    { 3, "hard" }
                });

            migrationBuilder.InsertData(
                table: "Quizs",
                column: "QuizID",
                values: new object[]
                {
                    1,
                    2
                });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "QuestionID", "CategoryID", "Text", "Type", "Weight" },
                values: new object[,]
                {
                    { 1, 1, "Java is.......", "multiplechoice", 1 },
                    { 5, 1, "‘Local variables are declared in methods, constructors, or blocks", "multiplechoice", 1 },
                    { 2, 2, "A Java class", "checkboxes", 1 },
                    { 3, 2, "What is java inheritance?", "multiplechoice", 1 },
                    { 6, 2, "……stores a fixed-size sequential collection of elements of the same type ? ", "multiplechoice", 1 },
                    { 4, 3, "Polymorphism is the ability of an object to take on many forms.", "multiplechoice", 1 }
                });

            migrationBuilder.InsertData(
                table: "Options",
                columns: new[] { "OptionID", "IsRight", "QuestionID", "Text" },
                values: new object[,]
                {
                    { 1, false, 1, "a coffee" },
                    { 10, false, 4, "false" },
                    { 9, true, 4, "true" },
                    { 15, false, 6, "methods" },
                    { 14, true, 6, "arrays" },
                    { 13, false, 6, "variables" },
                    { 8, false, 3, "it mainly used to traverse collection of elements including arrays." },
                    { 7, false, 3, "a problem that arises during the execution of a program" },
                    { 5, true, 2, "can have any number of methods" },
                    { 6, true, 3, "the process where one class acquires the properties (methods and fields) of another." },
                    { 12, false, 5, "false" },
                    { 11, true, 5, "true" },
                    { 3, false, 1, "a source code editor" },
                    { 2, true, 1, "a high-level programming language" },
                    { 4, true, 2, "is a template that describes the behavior that the object of its type support" }
                });

            migrationBuilder.InsertData(
                table: "QuestionQuizs",
                columns: new[] { "QuestionID", "QuizID" },
                values: new object[,]
                {
                    { 2, 1 },
                    { 4, 1 },
                    { 5, 2 },
                    { 3, 2 },
                    { 1, 2 },
                    { 1, 1 },
                    { 6, 1 },
                    { 4, 2 }
                });

            migrationBuilder.InsertData(
                table: "Anwsers",
                columns: new[] { "AnwserID", "OptionID", "QuizID" },
                values: new object[,]
                {
                    { 1, 1, 1 },
                    { 8, 1, 2 },
                    { 13, 11, 2 },
                    { 6, 12, 1 },
                    { 2, 4, 1 },
                    { 9, 4, 2 },
                    { 3, 5, 1 },
                    { 4, 6, 1 },
                    { 10, 7, 2 },
                    { 14, 13, 2 },
                    { 7, 14, 1 },
                    { 5, 9, 1 },
                    { 11, 9, 2 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Anwsers_OptionID",
                table: "Anwsers",
                column: "OptionID");

            migrationBuilder.CreateIndex(
                name: "IX_Anwsers_QuizID",
                table: "Anwsers",
                column: "QuizID");

            migrationBuilder.CreateIndex(
                name: "IX_Options_QuestionID",
                table: "Options",
                column: "QuestionID");

            migrationBuilder.CreateIndex(
                name: "IX_QuestionQuizs_QuizID",
                table: "QuestionQuizs",
                column: "QuizID");

            migrationBuilder.CreateIndex(
                name: "IX_Questions_CategoryID",
                table: "Questions",
                column: "CategoryID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Anwsers");

            migrationBuilder.DropTable(
                name: "QuestionQuizs");

            migrationBuilder.DropTable(
                name: "Options");

            migrationBuilder.DropTable(
                name: "Quizs");

            migrationBuilder.DropTable(
                name: "Questions");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
