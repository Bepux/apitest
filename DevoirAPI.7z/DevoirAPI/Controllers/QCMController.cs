﻿using DevoirAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DevoirAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QCMController : ControllerBase
    {
        private readonly QuizContext _context;

        public QCMController(QuizContext qc)
        {
            _context = qc;
        }

        [HttpGet("quiz")]
        public IActionResult quiz()
        {
            IList<string> marks = new List<string>();
            IList<Quiz> quizzes = _context.Quizs.ToArray();
            decimal count;

            foreach (Quiz q in quizzes)
            {
                IList<Anwser> anwsers = _context.Anwsers.Where(x => x.QuizID == q.QuizID).ToArray();
                IList<QuestionQuiz> questionQuizzes = _context.QuestionQuizs.Where(x => x.QuizID == q.QuizID).ToList();
                IList<Question> questions = new List<Question>();
                foreach (QuestionQuiz questionQuiz in questionQuizzes)
                {
                    questions.Add(_context.Questions.Where(x => x.QuestionID == questionQuiz.QuestionID).FirstOrDefault());
                }
                int totalMark = questions.Sum(x => x.Weight);
                count = 0;
                foreach (Anwser a in anwsers)
                {
                    Option o = _context.Options.Where(x => x.OptionID == a.OptionID).FirstOrDefault();
                    if (o.IsRight)
                    {
                        Question quest = _context.Questions.Where(x => x.QuestionID == o.QuestionID).FirstOrDefault();
                        if (quest.Type == "checkboxes")
                        {
                            IList<Option> options = _context.Options.Where(x => x.QuestionID == quest.QuestionID).ToList();
                            int validAnwser = options.Where(x => x.IsRight == true).Count();
                            count += quest.Weight/validAnwser;
                        }
                        else
                        {
                            count += quest.Weight;
                        }
                        
                    }
                }
                marks.Add("QuizID: " + q.QuizID + ", mark: " + count +"/" + totalMark);
            }
            return Ok(marks);
        }



        [HttpGet("quiz/{id}")]
        public IActionResult quiz(int id)
        {
            Quiz quiz = _context.Quizs.Where(x => x.QuizID == id).FirstOrDefault();

            if (quiz == null)
            {
                return NotFound("There is not quiz with that id");
            }

            IList<QuestionQuiz> ids = _context.QuestionQuizs.Where(x => x.QuizID == quiz.QuizID).ToArray();
            IList<Question> questions = new List<Question>();
            foreach (QuestionQuiz qq in ids)
            {
                questions.Add(_context.Questions.Where(x => x.QuestionID == qq.QuestionID).FirstOrDefault());
            }
            return Ok(questions);
        }

        [HttpGet("question/{id}")]
        public IActionResult question(int id)
        {
            Question question = _context.Questions.Where(x => id == x.QuestionID).FirstOrDefault();

            if (question == null)
            {
                return NotFound("There is no question with this id");
            }

            IList<Option> options = _context.Options.Where(x => x.QuestionID == question.QuestionID).ToArray();

            return Ok(options);

        }

        [HttpPost("quiz")]
        public IActionResult postQuiz([FromBody] QuizInfo[] data)
        {
            Random rng = new Random();
            _context.Add<Quiz>(new Quiz());
            _context.SaveChanges();
            Quiz q = _context.Quizs.OrderByDescending(X => X.QuizID).First();
            foreach (QuizInfo qi in data)
            {
                Category category = _context.Categories.Where(x => x.Description == qi.category).FirstOrDefault();
                int num = qi.numberOfQuestions;
                IList<Question> questions = _context.Questions.Where(x => x.CategoryID == category.CategoryID).ToArray();
                IList<Question> randomSelect = (from question in questions
                                                select question).OrderBy(x => Guid.NewGuid()).Take(num).ToList();
                foreach (Question quest in randomSelect)
                {
                    _context.Add<QuestionQuiz>(new QuestionQuiz() { QuestionID = quest.QuestionID, QuizID = q.QuizID });
                    _context.SaveChanges();
                }
            }
            return Ok(q.QuizID);
        }

        [HttpPost("quiz/{id}/anwsers")]
        public IActionResult postAnwsers(int id, [FromBody]int[] anwsers)
        {
            Quiz q = _context.Quizs.Where(x => x.QuizID == id).FirstOrDefault();
            foreach (int i in anwsers)
            {
                _context.Add<Anwser>(new Anwser() { QuizID = q.QuizID, OptionID = i });
                _context.SaveChanges();
            }
            return Ok();
        }
        




    }
}
